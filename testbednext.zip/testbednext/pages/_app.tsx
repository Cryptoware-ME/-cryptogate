import "../styles/globals.css";
import type { AppProps } from "next/app";
import { MultichainProvider } from "@cryptogate/react-providers";
import config from "../config";
import { useEffect } from "react";

function MyApp({ Component, pageProps }: AppProps) {
  useEffect(() => {
    console.log(config.ContractsConfig);
  }, []);

  return (
    <MultichainProvider
      ethConfig={config.DappConfig}
      solConfig={config.SolConfig}
      ethContracts={[]}
    >
      <Component {...pageProps} />
    </MultichainProvider>
  );
}

export default MyApp;
