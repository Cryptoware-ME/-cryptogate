const stage = "staging";

const SolappConfig = {
  config: {
    env: stage,
    autoConnect: false,
    lamportsPerSol: 1000000000,
  },
};

export default SolappConfig;
