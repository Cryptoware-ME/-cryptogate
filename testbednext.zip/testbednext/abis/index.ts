import OasisXAtomicizer from "./OasisXAtomicizer.json";
import OasisXRegistry from "./OasisXRegistry.json";
import OasisXExchange from "./OasisXExchange.json";
import OasisXStatic from "./OasisXStatic.json";
import ERC721 from "./ERC721.json";
import ERC20 from "./ERC20.json";
import ERC1155 from "./ERC1155.json";
import WEth from "./WEth.json";

export {
  OasisXAtomicizer,
  OasisXRegistry,
  OasisXExchange,
  OasisXStatic,
  ERC721,
  ERC20,
  ERC1155,
  WEth,
};
