/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./config/dapp.tsx":
/*!*************************!*\
  !*** ./config/dapp.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @cryptogate/react-providers */ \"@cryptogate/react-providers\");\n/* harmony import */ var _cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_0__);\n\nconst { ChainId , getChainById  } = _cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_0__.useDapp;\nconst DappConfig = {\n    readOnlyUrls: {\n        [ChainId.Mainnet]: `${\"https://eth-node.oasisx.world/\"}`,\n        [ChainId.Rinkeby]: `${\"https://rink-node.oasisx.world/\"}`,\n        [ChainId.Mumbai]: `${\"https://rpc.maticvigil.com/\"}`,\n        [ChainId.Polygon]: `${\"https://polygon-node.oasisx.world/\"}`,\n        [ChainId.BSC]: `${\"https://bsc-node.oasisx.world/\"}`,\n        [ChainId.Avalanche]: `${\"https://avalanche-node.oasisx.world/\"}`\n    },\n    appName: \"Cryptogate\",\n    appEmail: \"cryptoware@yahoo.com\",\n    appUrl: \"cryptoware.me\",\n    appLogo: \"\",\n    pollingInterval: 1000,\n    networks: [\n        getChainById(ChainId.Rinkeby),\n        getChainById(ChainId.Mainnet),\n        getChainById(ChainId.Mumbai),\n        getChainById(ChainId.Polygon),\n        getChainById(ChainId.BSC),\n        getChainById(ChainId.Avalanche), \n    ],\n    notifications: {\n        checkInterval: 1000,\n        expirationPeriod: 10000\n    },\n    autoConnect: false\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DappConfig);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb25maWcvZGFwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQXNEO0FBRXRELE1BQU0sRUFBRUMsT0FBTyxHQUFFQyxZQUFZLEdBQUUsR0FBR0YsZ0VBQU87QUFFekMsTUFBTUcsVUFBVSxHQUFHO0lBQ2pCQyxZQUFZLEVBQUU7UUFDWixDQUFDSCxPQUFPLENBQUNJLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRUMsZ0NBQXdDLENBQUMsQ0FBQztRQUNoRSxDQUFDTCxPQUFPLENBQUNRLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRUgsaUNBQXdDLENBQUMsQ0FBQztRQUNoRSxDQUFDTCxPQUFPLENBQUNVLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRUwsNkJBQXVDLENBQUMsQ0FBQztRQUM5RCxDQUFDTCxPQUFPLENBQUNZLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRVAsb0NBQXdDLENBQUMsQ0FBQztRQUNoRSxDQUFDTCxPQUFPLENBQUNjLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRVQsZ0NBQW9DLENBQUMsQ0FBQztRQUN4RCxDQUFDTCxPQUFPLENBQUNnQixTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUVYLHNDQUEwQyxDQUFDLENBQUM7S0FDckU7SUFDRGEsT0FBTyxFQUFFLFlBQVk7SUFDckJDLFFBQVEsRUFBRSxzQkFBc0I7SUFDaENDLE1BQU0sRUFBRSxlQUFlO0lBQ3ZCQyxPQUFPLEVBQUUsRUFBRTtJQUNYQyxlQUFlLEVBQUUsSUFBSTtJQUNyQkMsUUFBUSxFQUFFO1FBQ1J0QixZQUFZLENBQUNELE9BQU8sQ0FBQ1EsT0FBTyxDQUFDO1FBQzdCUCxZQUFZLENBQUNELE9BQU8sQ0FBQ0ksT0FBTyxDQUFDO1FBQzdCSCxZQUFZLENBQUNELE9BQU8sQ0FBQ1UsTUFBTSxDQUFDO1FBQzVCVCxZQUFZLENBQUNELE9BQU8sQ0FBQ1ksT0FBTyxDQUFDO1FBQzdCWCxZQUFZLENBQUNELE9BQU8sQ0FBQ2MsR0FBRyxDQUFDO1FBQ3pCYixZQUFZLENBQUNELE9BQU8sQ0FBQ2dCLFNBQVMsQ0FBQztLQUNoQztJQUNEUSxhQUFhLEVBQUU7UUFDYkMsYUFBYSxFQUFFLElBQUk7UUFDbkJDLGdCQUFnQixFQUFFLEtBQUs7S0FDeEI7SUFDREMsV0FBVyxFQUFFLEtBQUs7Q0FDbkI7QUFFRCxpRUFBZXpCLFVBQVUsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Rlc3RiZWRuZXh0Ly4vY29uZmlnL2RhcHAudHN4PzE5ZmQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRGFwcCB9IGZyb20gXCJAY3J5cHRvZ2F0ZS9yZWFjdC1wcm92aWRlcnNcIjtcclxuXHJcbmNvbnN0IHsgQ2hhaW5JZCwgZ2V0Q2hhaW5CeUlkIH0gPSB1c2VEYXBwO1xyXG5cclxuY29uc3QgRGFwcENvbmZpZyA9IHtcclxuICByZWFkT25seVVybHM6IHtcclxuICAgIFtDaGFpbklkLk1haW5uZXRdOiBgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19OT0RFX1VSTF9NQUlOTkVUfWAsXHJcbiAgICBbQ2hhaW5JZC5SaW5rZWJ5XTogYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTk9ERV9VUkxfUklOS0VCWX1gLFxyXG4gICAgW0NoYWluSWQuTXVtYmFpXTogYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTk9ERV9VUkxfTVVNQkFJfWAsXHJcbiAgICBbQ2hhaW5JZC5Qb2x5Z29uXTogYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTk9ERV9VUkxfUE9MWUdPTn1gLFxyXG4gICAgW0NoYWluSWQuQlNDXTogYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTk9ERV9VUkxfQlNDfWAsXHJcbiAgICBbQ2hhaW5JZC5BdmFsYW5jaGVdOiBgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19OT0RFX1VSTF9BVkFMQU5DSEV9YCxcclxuICB9LFxyXG4gIGFwcE5hbWU6IFwiQ3J5cHRvZ2F0ZVwiLFxyXG4gIGFwcEVtYWlsOiBcImNyeXB0b3dhcmVAeWFob28uY29tXCIsXHJcbiAgYXBwVXJsOiBcImNyeXB0b3dhcmUubWVcIixcclxuICBhcHBMb2dvOiBcIlwiLFxyXG4gIHBvbGxpbmdJbnRlcnZhbDogMTAwMCxcclxuICBuZXR3b3JrczogW1xyXG4gICAgZ2V0Q2hhaW5CeUlkKENoYWluSWQuUmlua2VieSksXHJcbiAgICBnZXRDaGFpbkJ5SWQoQ2hhaW5JZC5NYWlubmV0KSxcclxuICAgIGdldENoYWluQnlJZChDaGFpbklkLk11bWJhaSksXHJcbiAgICBnZXRDaGFpbkJ5SWQoQ2hhaW5JZC5Qb2x5Z29uKSxcclxuICAgIGdldENoYWluQnlJZChDaGFpbklkLkJTQyksXHJcbiAgICBnZXRDaGFpbkJ5SWQoQ2hhaW5JZC5BdmFsYW5jaGUpLFxyXG4gIF0sXHJcbiAgbm90aWZpY2F0aW9uczoge1xyXG4gICAgY2hlY2tJbnRlcnZhbDogMTAwMCxcclxuICAgIGV4cGlyYXRpb25QZXJpb2Q6IDEwMDAwLFxyXG4gIH0sXHJcbiAgYXV0b0Nvbm5lY3Q6IGZhbHNlLFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFwcENvbmZpZztcclxuIl0sIm5hbWVzIjpbInVzZURhcHAiLCJDaGFpbklkIiwiZ2V0Q2hhaW5CeUlkIiwiRGFwcENvbmZpZyIsInJlYWRPbmx5VXJscyIsIk1haW5uZXQiLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfTk9ERV9VUkxfTUFJTk5FVCIsIlJpbmtlYnkiLCJORVhUX1BVQkxJQ19OT0RFX1VSTF9SSU5LRUJZIiwiTXVtYmFpIiwiTkVYVF9QVUJMSUNfTk9ERV9VUkxfTVVNQkFJIiwiUG9seWdvbiIsIk5FWFRfUFVCTElDX05PREVfVVJMX1BPTFlHT04iLCJCU0MiLCJORVhUX1BVQkxJQ19OT0RFX1VSTF9CU0MiLCJBdmFsYW5jaGUiLCJORVhUX1BVQkxJQ19OT0RFX1VSTF9BVkFMQU5DSEUiLCJhcHBOYW1lIiwiYXBwRW1haWwiLCJhcHBVcmwiLCJhcHBMb2dvIiwicG9sbGluZ0ludGVydmFsIiwibmV0d29ya3MiLCJub3RpZmljYXRpb25zIiwiY2hlY2tJbnRlcnZhbCIsImV4cGlyYXRpb25QZXJpb2QiLCJhdXRvQ29ubmVjdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./config/dapp.tsx\n");

/***/ }),

/***/ "./config/index.tsx":
/*!**************************!*\
  !*** ./config/index.tsx ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _dapp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dapp */ \"./config/dapp.tsx\");\n/* harmony import */ var _solapp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./solapp */ \"./config/solapp.tsx\");\n\n\nconst config = {\n    DappConfig: {\n        ..._dapp__WEBPACK_IMPORTED_MODULE_0__[\"default\"]\n    },\n    SolConfig: _solapp__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb25maWcvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUNJO0FBRXBDLE1BQU1FLE1BQU0sR0FBRztJQUNiRixVQUFVLEVBQUU7UUFBRSxHQUFHQSw2Q0FBVTtLQUFFO0lBQzdCRyxTQUFTLEVBQUVGLCtDQUFZO0NBQ3hCO0FBQ0QsaUVBQWVDLE1BQU0sRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Rlc3RiZWRuZXh0Ly4vY29uZmlnL2luZGV4LnRzeD9iYjc1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBEYXBwQ29uZmlnIGZyb20gXCIuL2RhcHBcIjtcclxuaW1wb3J0IFNvbGFwcENvbmZpZyBmcm9tIFwiLi9zb2xhcHBcIjtcclxuXHJcbmNvbnN0IGNvbmZpZyA9IHtcclxuICBEYXBwQ29uZmlnOiB7IC4uLkRhcHBDb25maWcgfSxcclxuICBTb2xDb25maWc6IFNvbGFwcENvbmZpZyxcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgY29uZmlnO1xyXG4iXSwibmFtZXMiOlsiRGFwcENvbmZpZyIsIlNvbGFwcENvbmZpZyIsImNvbmZpZyIsIlNvbENvbmZpZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./config/index.tsx\n");

/***/ }),

/***/ "./config/solapp.tsx":
/*!***************************!*\
  !*** ./config/solapp.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst stage = \"staging\";\nconst SolappConfig = {\n    config: {\n        env: stage,\n        autoConnect: false,\n        lamportsPerSol: 1000000000\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SolappConfig);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb25maWcvc29sYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsTUFBTUEsS0FBSyxHQUFHLFNBQVM7QUFFdkIsTUFBTUMsWUFBWSxHQUFHO0lBQ25CQyxNQUFNLEVBQUU7UUFDTkMsR0FBRyxFQUFFSCxLQUFLO1FBQ1ZJLFdBQVcsRUFBRSxLQUFLO1FBQ2xCQyxjQUFjLEVBQUUsVUFBVTtLQUMzQjtDQUNGO0FBRUQsaUVBQWVKLFlBQVksRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Rlc3RiZWRuZXh0Ly4vY29uZmlnL3NvbGFwcC50c3g/NDgxYSJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzdGFnZSA9IFwic3RhZ2luZ1wiO1xyXG5cclxuY29uc3QgU29sYXBwQ29uZmlnID0ge1xyXG4gIGNvbmZpZzoge1xyXG4gICAgZW52OiBzdGFnZSxcclxuICAgIGF1dG9Db25uZWN0OiBmYWxzZSxcclxuICAgIGxhbXBvcnRzUGVyU29sOiAxMDAwMDAwMDAwLFxyXG4gIH0sXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTb2xhcHBDb25maWc7XHJcbiJdLCJuYW1lcyI6WyJzdGFnZSIsIlNvbGFwcENvbmZpZyIsImNvbmZpZyIsImVudiIsImF1dG9Db25uZWN0IiwibGFtcG9ydHNQZXJTb2wiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./config/solapp.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cryptogate/react-providers */ \"@cryptogate/react-providers\");\n/* harmony import */ var _cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config */ \"./config/index.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{\n        console.log(_config__WEBPACK_IMPORTED_MODULE_3__[\"default\"].ContractsConfig);\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_cryptogate_react_providers__WEBPACK_IMPORTED_MODULE_2__.MultichainProvider, {\n        ethConfig: _config__WEBPACK_IMPORTED_MODULE_3__[\"default\"].DappConfig,\n        solConfig: _config__WEBPACK_IMPORTED_MODULE_3__[\"default\"].SolConfig,\n        ethContracts: [],\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\_app.tsx\",\n            lineNumber: 18,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\_app.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFBK0I7QUFFa0M7QUFDbEM7QUFDRztBQUVsQyxTQUFTRyxLQUFLLENBQUMsRUFBRUMsU0FBUyxHQUFFQyxTQUFTLEdBQVksRUFBRTtJQUNqREgsZ0RBQVMsQ0FBQyxJQUFNO1FBQ2RJLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDTiwrREFBc0IsQ0FBQyxDQUFDO0tBQ3JDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFUCxxQkFDRSw4REFBQ0QsMkVBQWtCO1FBQ2pCUyxTQUFTLEVBQUVSLDBEQUFpQjtRQUM1QlUsU0FBUyxFQUFFVix5REFBZ0I7UUFDM0JZLFlBQVksRUFBRSxFQUFFO2tCQUVoQiw0RUFBQ1QsU0FBUztZQUFFLEdBQUdDLFNBQVM7Ozs7O2dCQUFJOzs7OztZQUNULENBQ3JCO0NBQ0g7QUFFRCxpRUFBZUYsS0FBSyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzdGJlZG5leHQvLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gXCJuZXh0L2FwcFwiO1xuaW1wb3J0IHsgTXVsdGljaGFpblByb3ZpZGVyIH0gZnJvbSBcIkBjcnlwdG9nYXRlL3JlYWN0LXByb3ZpZGVyc1wiO1xuaW1wb3J0IGNvbmZpZyBmcm9tIFwiLi4vY29uZmlnXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGNvbmZpZy5Db250cmFjdHNDb25maWcpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8TXVsdGljaGFpblByb3ZpZGVyXG4gICAgICBldGhDb25maWc9e2NvbmZpZy5EYXBwQ29uZmlnfVxuICAgICAgc29sQ29uZmlnPXtjb25maWcuU29sQ29uZmlnfVxuICAgICAgZXRoQ29udHJhY3RzPXtbXX1cbiAgICA+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9NdWx0aWNoYWluUHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xuIl0sIm5hbWVzIjpbIk11bHRpY2hhaW5Qcm92aWRlciIsImNvbmZpZyIsInVzZUVmZmVjdCIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiY29uc29sZSIsImxvZyIsIkNvbnRyYWN0c0NvbmZpZyIsImV0aENvbmZpZyIsIkRhcHBDb25maWciLCJzb2xDb25maWciLCJTb2xDb25maWciLCJldGhDb250cmFjdHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@cryptogate/react-providers":
/*!**********************************************!*\
  !*** external "@cryptogate/react-providers" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@cryptogate/react-providers");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();