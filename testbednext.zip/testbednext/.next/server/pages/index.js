/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./styles/Home.module.css":
/*!********************************!*\
  !*** ./styles/Home.module.css ***!
  \********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"Home_container__bCOhY\",\n\t\"main\": \"Home_main__nLjiQ\",\n\t\"footer\": \"Home_footer____T7K\",\n\t\"title\": \"Home_title__T09hD\",\n\t\"description\": \"Home_description__41Owk\",\n\t\"code\": \"Home_code__suPER\",\n\t\"grid\": \"Home_grid__GxQ85\",\n\t\"card\": \"Home_card___LpL1\",\n\t\"logo\": \"Home_logo__27_tb\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3Rlc3RiZWRuZXh0Ly4vc3R5bGVzL0hvbWUubW9kdWxlLmNzcz9iMTcwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImNvbnRhaW5lclwiOiBcIkhvbWVfY29udGFpbmVyX19iQ09oWVwiLFxuXHRcIm1haW5cIjogXCJIb21lX21haW5fX25MamlRXCIsXG5cdFwiZm9vdGVyXCI6IFwiSG9tZV9mb290ZXJfX19fVDdLXCIsXG5cdFwidGl0bGVcIjogXCJIb21lX3RpdGxlX19UMDloRFwiLFxuXHRcImRlc2NyaXB0aW9uXCI6IFwiSG9tZV9kZXNjcmlwdGlvbl9fNDFPd2tcIixcblx0XCJjb2RlXCI6IFwiSG9tZV9jb2RlX19zdVBFUlwiLFxuXHRcImdyaWRcIjogXCJIb21lX2dyaWRfX0d4UTg1XCIsXG5cdFwiY2FyZFwiOiBcIkhvbWVfY2FyZF9fX0xwTDFcIixcblx0XCJsb2dvXCI6IFwiSG9tZV9sb2dvX18yN190YlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/Home.module.css\n");

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/Home.module.css */ \"./styles/Home.module.css\");\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cryptogate/react-ui */ \"@cryptogate/react-ui\");\n/* harmony import */ var _cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _cryptogate_react_ui_dist_cjs_index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cryptogate/react-ui/dist/cjs/index.css */ \"./node_modules/@cryptogate/react-ui/dist/cjs/index.css\");\n/* harmony import */ var _cryptogate_react_ui_dist_cjs_index_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_cryptogate_react_ui_dist_cjs_index_css__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\n\nconst Home = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_4___default().container),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"Cryptogate test\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                        lineNumber: 15,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"description\",\n                        content: \"Generated by create next app\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                        lineNumber: 16,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"icon\",\n                        href: \"/favicon.ico\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                        lineNumber: 17,\n                        columnNumber: 9\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                lineNumber: 14,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_4___default().main),\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2__.ConnectWalletComponent, {\n                    EthWalletList: [\n                        _cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2__.EthWallets.ALL\n                    ],\n                    ConnectedMenuChosen: _cryptogate_react_ui__WEBPACK_IMPORTED_MODULE_2__.ConnectedMenu.STORE,\n                    Store: {\n                        Tokens: [\n                            \"0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2\",\n                            \"0xD417144312DbF50465b1C641d016962017Ef6240\",\n                            \"0x3f7674Ddeb6422B77719B48c914158021034801e\",\n                            \"0xB8c77482e45F1F44dE1745F52C74426C631bDD52\",\n                            \"0x667fd83e24ca1d935d36717d305d54fa0cac991c\", \n                        ],\n                        NFTs: [\n                            \"0x4feec948eb3d6a2eb37560d4b2c16f1c9fe72ef6\",\n                            \"0x3605b7d5ff9d6fa953a323dcf10dc747f8e75dfa\",\n                            \"0x10a0cf0fd3b9b2d575d78130b29d61252313423e\",\n                            \"0xeE29700134AAB4f45b113E43E29ff06ce10687b7\",\n                            \"0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D\"\n                        ]\n                    }\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                    lineNumber: 22,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n                lineNumber: 19,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Karim Deaibes\\\\Desktop\\\\Cryptoware\\\\Projects\\\\Cryptogate\\\\cryptogate-packages\\\\testbednext\\\\pages\\\\index.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUM2QjtBQUNrQjtBQUtqQjtBQUNrQjtBQUVoRCxNQUFNSyxJQUFJLEdBQWEsSUFBTTtJQUMzQixxQkFDRSw4REFBQ0MsS0FBRztRQUFDQyxTQUFTLEVBQUVOLDBFQUFnQjs7MEJBQzlCLDhEQUFDRCxrREFBSTs7a0NBQ0gsOERBQUNTLE9BQUs7a0NBQUMsaUJBQWU7Ozs7O2lDQUFRO2tDQUM5Qiw4REFBQ0MsTUFBSTt3QkFBQ0MsSUFBSSxFQUFDLGFBQWE7d0JBQUNDLE9BQU8sRUFBQyw4QkFBOEI7Ozs7O2lDQUFHO2tDQUNsRSw4REFBQ0MsTUFBSTt3QkFBQ0MsR0FBRyxFQUFDLE1BQU07d0JBQUNDLElBQUksRUFBQyxjQUFjOzs7OztpQ0FBRzs7Ozs7O3lCQUNsQzswQkFDUCw4REFBQ0MsTUFBSTtnQkFBQ1QsU0FBUyxFQUFFTixxRUFBVzswQkFHMUIsNEVBQUNDLHdFQUFzQjtvQkFDckJlLGFBQWEsRUFBRTt3QkFBQ2QsZ0VBQWM7cUJBQUM7b0JBQy9CZ0IsbUJBQW1CLEVBQUVmLHFFQUFtQjtvQkFDeENpQixLQUFLLEVBQUU7d0JBQ0xDLE1BQU0sRUFBRTs0QkFDTiw0Q0FBNEM7NEJBQzVDLDRDQUE0Qzs0QkFDNUMsNENBQTRDOzRCQUM1Qyw0Q0FBNEM7NEJBQzVDLDRDQUE0Qzt5QkFDN0M7d0JBQ0RDLElBQUksRUFBRTs0QkFDSiw0Q0FBNEM7NEJBQzVDLDRDQUE0Qzs0QkFDNUMsNENBQTRDOzRCQUM1Qyw0Q0FBNEM7NEJBQzVDLDRDQUE0Qzt5QkFDN0M7cUJBQ0Y7Ozs7OzZCQUNEOzs7Ozt5QkFFRzs7Ozs7O2lCQUNILENBQ047Q0FDSDtBQUVELGlFQUFlbEIsSUFBSSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzdGJlZG5leHQvLi9wYWdlcy9pbmRleC50c3g/MDdmZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5leHRQYWdlIH0gZnJvbSBcIm5leHRcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3NcIjtcbmltcG9ydCB7XG4gIENvbm5lY3RXYWxsZXRDb21wb25lbnQsXG4gIEV0aFdhbGxldHMsXG4gIENvbm5lY3RlZE1lbnUsXG59IGZyb20gXCJAY3J5cHRvZ2F0ZS9yZWFjdC11aVwiO1xuaW1wb3J0IFwiQGNyeXB0b2dhdGUvcmVhY3QtdWkvZGlzdC9janMvaW5kZXguY3NzXCJcblxuY29uc3QgSG9tZTogTmV4dFBhZ2UgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcnlwdG9nYXRlIHRlc3Q8L3RpdGxlPlxuICAgICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PVwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiIC8+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT17c3R5bGVzLm1haW59PlxuXG4gICAgICAgIHsvKiAtLS0tLS0tLS0tLS0tIENSWVBUT0dBVEUgLS0tLS0tLS0tLS0tLSAqL31cbiAgICAgICAgPENvbm5lY3RXYWxsZXRDb21wb25lbnRcbiAgICAgICAgICBFdGhXYWxsZXRMaXN0PXtbRXRoV2FsbGV0cy5BTExdfVxuICAgICAgICAgIENvbm5lY3RlZE1lbnVDaG9zZW49e0Nvbm5lY3RlZE1lbnUuU1RPUkV9XG4gICAgICAgICAgU3RvcmU9e3tcbiAgICAgICAgICAgIFRva2VuczogW1xuICAgICAgICAgICAgICBcIjB4YzAyYWFhMzliMjIzZmU4ZDBhMGU1YzRmMjdlYWQ5MDgzYzc1NmNjMlwiLFxuICAgICAgICAgICAgICBcIjB4RDQxNzE0NDMxMkRiRjUwNDY1YjFDNjQxZDAxNjk2MjAxN0VmNjI0MFwiLFxuICAgICAgICAgICAgICBcIjB4M2Y3Njc0RGRlYjY0MjJCNzc3MTlCNDhjOTE0MTU4MDIxMDM0ODAxZVwiLFxuICAgICAgICAgICAgICBcIjB4QjhjNzc0ODJlNDVGMUY0NGRFMTc0NUY1MkM3NDQyNkM2MzFiREQ1MlwiLFxuICAgICAgICAgICAgICBcIjB4NjY3ZmQ4M2UyNGNhMWQ5MzVkMzY3MTdkMzA1ZDU0ZmEwY2FjOTkxY1wiLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIE5GVHM6IFtcbiAgICAgICAgICAgICAgXCIweDRmZWVjOTQ4ZWIzZDZhMmViMzc1NjBkNGIyYzE2ZjFjOWZlNzJlZjZcIiwgLy9NZXRhcHJlbmV1cnNcbiAgICAgICAgICAgICAgXCIweDM2MDViN2Q1ZmY5ZDZmYTk1M2EzMjNkY2YxMGRjNzQ3ZjhlNzVkZmFcIiwgLy8gQkhpdmVcbiAgICAgICAgICAgICAgXCIweDEwYTBjZjBmZDNiOWIyZDU3NWQ3ODEzMGIyOWQ2MTI1MjMxMzQyM2VcIiwgLy9TdXJ2aXZvclxuICAgICAgICAgICAgICBcIjB4ZUUyOTcwMDEzNEFBQjRmNDViMTEzRTQzRTI5ZmYwNmNlMTA2ODdiN1wiLCAvL0NhcnRvb25cbiAgICAgICAgICAgICAgXCIweEJDNENBMEVkQTc2NDdBOGFCN0MyMDYxYzJFMTE4QTE4YTkzNmYxM0RcIiwgLy8gQkFZQ1xuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgICB7LyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi99XG4gICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIb21lO1xuIl0sIm5hbWVzIjpbIkhlYWQiLCJzdHlsZXMiLCJDb25uZWN0V2FsbGV0Q29tcG9uZW50IiwiRXRoV2FsbGV0cyIsIkNvbm5lY3RlZE1lbnUiLCJIb21lIiwiZGl2IiwiY2xhc3NOYW1lIiwiY29udGFpbmVyIiwidGl0bGUiLCJtZXRhIiwibmFtZSIsImNvbnRlbnQiLCJsaW5rIiwicmVsIiwiaHJlZiIsIm1haW4iLCJFdGhXYWxsZXRMaXN0IiwiQUxMIiwiQ29ubmVjdGVkTWVudUNob3NlbiIsIlNUT1JFIiwiU3RvcmUiLCJUb2tlbnMiLCJORlRzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "./node_modules/@cryptogate/react-ui/dist/cjs/index.css":
/*!**************************************************************!*\
  !*** ./node_modules/@cryptogate/react-ui/dist/cjs/index.css ***!
  \**************************************************************/
/***/ (() => {



/***/ }),

/***/ "@cryptogate/react-ui":
/*!***************************************!*\
  !*** external "@cryptogate/react-ui" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@cryptogate/react-ui");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();